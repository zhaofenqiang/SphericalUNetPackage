This is the package for [Spherical U-Net](https://github.com/zhaofenqiang/Spherical_U-Net) code.
